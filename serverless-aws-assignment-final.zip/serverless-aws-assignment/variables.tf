variable "aws_region" { type = string default = "ap-south-1" description = "AWS region" }
variable "environment" { type = string default = "dev" description = "Deployment environment" }
variable "api_reserved_concurrency" { type = number default = 10 description = "Reserved concurrency for API Lambda" }
variable "api_provisioned_concurrency" { type = number default = 2 description = "Provisioned concurrency for the API live alias" }
variable "enable_provisioned_concurrency" { type = bool default = true description = "Enable provisioned concurrency" }
variable "enable_lambda_insights" { type = bool default = true description = "Attach AWS Lambda Insights extension" }
variable "lambda_insights_layer_arn" { type = string default = "arn:aws:lambda:ap-south-1:580247275435:layer:LambdaInsightsExtension:62" description = "Lambda Insights extension layer ARN. Change for another AWS region." }
