package main

import (
    "bytes"
    "encoding/json"
    "fmt"
    "io"
    "log"
    "net/http"
    "os"
)

func main() {
    api := os.Getenv("AWS_LAMBDA_RUNTIME_API")
    if api == "" { log.Fatal("AWS_LAMBDA_RUNTIME_API is not set") }
    client := &http.Client{}
    for {
        req, err := http.NewRequest("GET", "http://"+api+"/2018-06-01/runtime/invocation/next", nil)
        if err != nil { log.Fatal(err) }
        resp, err := client.Do(req)
        if err != nil { log.Fatal(err) }
        requestID := resp.Header.Get("Lambda-Runtime-Aws-Request-Id")
        payload, err := io.ReadAll(resp.Body)
        resp.Body.Close()
        if err != nil { postError(client, api, requestID, err); continue }
        var event any
        _ = json.Unmarshal(payload, &event)
        result := map[string]any{"success": true, "runtime": "provided.al2023", "message": "EventBridge custom runtime executed", "event": event, "environment": os.Getenv("ENVIRONMENT")}
        out, _ := json.Marshal(result)
        log.Printf(`{"event":"custom_runtime_completed","request_id":"%s","environment":"%s"}`, requestID, os.Getenv("ENVIRONMENT"))
        url := fmt.Sprintf("http://%s/2018-06-01/runtime/invocation/%s/response", api, requestID)
        r, _ := http.NewRequest("POST", url, bytes.NewReader(out)); r.Header.Set("Content-Type", "application/json")
        rr, err := client.Do(r); if err == nil { rr.Body.Close() }
    }
}

func postError(client *http.Client, api, id string, err error) {
    body, _ := json.Marshal(map[string]string{"errorType":"RuntimeError", "errorMessage":err.Error()})
    url := fmt.Sprintf("http://%s/2018-06-01/runtime/invocation/%s/error", api, id)
    r, _ := http.NewRequest("POST", url, bytes.NewReader(body)); r.Header.Set("Content-Type", "application/json")
    rr, _ := client.Do(r); if rr != nil { rr.Body.Close() }
}
