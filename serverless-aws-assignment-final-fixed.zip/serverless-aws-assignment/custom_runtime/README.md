# Custom runtime

`bootstrap` is a statically linked Go implementation of the AWS Lambda Runtime API for `provided.al2023`, built for Linux x86_64. `main.go` is included as the source. Terraform packages this directory automatically with `archive_file` and deploys it as the EventBridge scheduled Lambda.
