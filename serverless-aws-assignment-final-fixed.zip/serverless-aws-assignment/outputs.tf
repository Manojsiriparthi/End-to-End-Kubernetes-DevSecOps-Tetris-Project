output "api_url" {
  value = "https://${aws_api_gateway_rest_api.api.id}.execute-api.${var.aws_region}.amazonaws.com/${aws_api_gateway_stage.dev.stage_name}"
}

output "api_id" {
  value = aws_api_gateway_rest_api.api.id
}

output "api_key_id" {
  value = aws_api_gateway_api_key.client.id
}

output "api_lambda_name" {
  value = aws_lambda_function.api.function_name
}

output "api_live_alias" {
  value = aws_lambda_alias.api_live.arn
}

output "api_version" {
  value = aws_lambda_function.api.version
}

output "s3_bucket" {
  value = aws_s3_bucket.uploads.bucket
}

output "sqs_queue_url" {
  value = aws_sqs_queue.main.url
}

output "scheduled_lambda_name" {
  value = aws_lambda_function.scheduled.function_name
}

output "insights_layer" {
  value = var.enable_lambda_insights ? var.lambda_insights_layer_arn : "disabled"
}
