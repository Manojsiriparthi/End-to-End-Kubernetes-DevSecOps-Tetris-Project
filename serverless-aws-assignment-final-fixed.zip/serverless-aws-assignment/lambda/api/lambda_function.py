import json
import logging
import os
import resource
import time
import uuid

from common.logger import log_event

logger = logging.getLogger()
logger.setLevel(os.getenv("LOG_LEVEL", "INFO"))


def make_response(status_code, data=None, error=None, correlation_id=None):
    return {
        "statusCode": status_code,
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Headers": "Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Correlation-ID",
            "Access-Control-Allow-Methods": "GET,POST,PUT,DELETE,OPTIONS",
            "X-Correlation-ID": correlation_id,
        },
        "body": json.dumps({
            "success": status_code < 400,
            "data": data if status_code < 400 else None,
            "error": error if status_code >= 400 else None,
            "correlation_id": correlation_id,
        }),
    }


def memory_used_mb():
    # Linux Lambda REPORT logs expose Max Memory Used. This custom metric uses
    # the Python process high-water RSS as an application-level memory metric.
    return round(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024, 2)


def lambda_handler(event, context):
    start = time.perf_counter()
    headers = event.get("headers") or {}
    correlation_id = headers.get("X-Correlation-ID") or headers.get("x-correlation-id") or str(uuid.uuid4())
    method = event.get("httpMethod", "GET")
    path = event.get("path", "/")
    resource_path = event.get("resource", path)

    log_event("request_received", correlation_id=correlation_id, request_id=context.aws_request_id,
              method=method, path=path, resource=resource_path, function=context.function_name)

    try:
        qs = event.get("queryStringParameters") or {}
        sleep_seconds = min(max(int(qs.get("sleep", "0")), 0), 10)
        if sleep_seconds:
            time.sleep(sleep_seconds)
        if qs.get("force_error") == "true":
            raise RuntimeError("Intentional test error")

        raw_body = event.get("body")
        body = None
        if raw_body:
            try:
                body = json.loads(raw_body)
            except json.JSONDecodeError:
                return make_response(400, error={"code": "INVALID_JSON", "message": "Request body must be valid JSON"}, correlation_id=correlation_id)

        item_id = (event.get("pathParameters") or {}).get("id")

        if path.startswith("/users"):
            if method == "GET" and not item_id:
                return make_response(200, data={"resource": "users", "message": "Users retrieved", "limit": qs.get("limit"), "table": os.getenv("TABLE_NAME")}, correlation_id=correlation_id)
            if method == "POST" and not item_id:
                return make_response(201, data={"resource": "users", "message": "User created", "request": body}, correlation_id=correlation_id)
            if method == "GET" and item_id:
                return make_response(200, data={"resource": "user", "id": item_id, "message": "User retrieved"}, correlation_id=correlation_id)
            if method == "PUT" and item_id:
                return make_response(200, data={"resource": "user", "id": item_id, "message": "User updated", "request": body}, correlation_id=correlation_id)
            if method == "DELETE" and item_id:
                return make_response(200, data={"resource": "user", "id": item_id, "message": "User deleted"}, correlation_id=correlation_id)

        if path.startswith("/products"):
            if method == "GET" and not item_id:
                return make_response(200, data={"resource": "products", "message": "Products retrieved"}, correlation_id=correlation_id)
            if method == "POST" and not item_id:
                return make_response(201, data={"resource": "products", "message": "Product created", "request": body}, correlation_id=correlation_id)
            if method == "GET" and item_id:
                return make_response(200, data={"resource": "product", "id": item_id, "message": "Product retrieved"}, correlation_id=correlation_id)
            if method == "PUT" and item_id:
                return make_response(200, data={"resource": "product", "id": item_id, "message": "Product updated", "request": body}, correlation_id=correlation_id)
            if method == "DELETE" and item_id:
                return make_response(200, data={"resource": "product", "id": item_id, "message": "Product deleted"}, correlation_id=correlation_id)

        return make_response(404, error={"code": "NOT_FOUND", "message": "Resource or endpoint not found"}, correlation_id=correlation_id)
    except Exception as exc:
        log_event("request_failed", correlation_id=correlation_id, request_id=context.aws_request_id, error=str(exc))
        return make_response(500, error={"code": "INTERNAL_ERROR", "message": "Internal server error"}, correlation_id=correlation_id)
    finally:
        duration_ms = round((time.perf_counter() - start) * 1000, 2)
        log_event("request_completed", correlation_id=correlation_id, duration_ms=duration_ms, memory_used_mb=memory_used_mb())
