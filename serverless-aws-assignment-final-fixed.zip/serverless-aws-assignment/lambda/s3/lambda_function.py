import logging
import os

from common.logger import log_event

logger = logging.getLogger()
logger.setLevel(os.getenv("LOG_LEVEL", "INFO"))


def lambda_handler(event, context):
    records = event.get("Records", [])

    log_event(
        "s3_event_received",
        request_id=context.aws_request_id,
        record_count=len(records),
    )

    for record in records:
        bucket = record["s3"]["bucket"]["name"]
        key = record["s3"]["object"]["key"]

        log_event(
            "s3_object_created",
            request_id=context.aws_request_id,
            bucket=bucket,
            key=key,
        )

    return {
        "statusCode": 200,
        "message": "S3 event processed successfully",
        "processed_records": len(records),
    }
