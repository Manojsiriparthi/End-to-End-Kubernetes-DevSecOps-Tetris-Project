import logging
import os

from common.logger import log_event

logger = logging.getLogger()
logger.setLevel(os.getenv("LOG_LEVEL", "INFO"))


def lambda_handler(event, context):
    records = event.get("Records", [])

    log_event(
        "sqs_batch_received",
        request_id=context.aws_request_id,
        record_count=len(records),
    )

    for record in records:
        log_event(
            "sqs_message_processed",
            request_id=context.aws_request_id,
            message_id=record.get("messageId"),
            body=record.get("body"),
        )

    return {
        "statusCode": 200,
        "message": "SQS messages processed",
        "count": len(records),
    }
