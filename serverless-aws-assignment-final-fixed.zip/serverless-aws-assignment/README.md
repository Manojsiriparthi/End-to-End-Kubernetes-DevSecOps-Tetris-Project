# AWS Serverless Assignment — Complete Terraform Project

This project implements the assignment end-to-end: four Lambda workloads, S3/SQS/EventBridge integrations, REST API Gateway, validation, API keys/usage plans, throttling, CORS, CloudWatch logging/metrics, Lambda Layer, reserved/provisioned concurrency, Lambda Insights, a custom runtime, OpenAPI documentation, and reproducible tests.

## Architecture

- **API Lambda** — Python 3.12, Lambda Layer, Lambda Insights, reserved concurrency 10, `live` alias, provisioned concurrency 2.
- **S3 Lambda** — triggered by ObjectCreated events.
- **SQS Lambda** — consumes messages from an SQS queue.
- **Scheduled Lambda** — EventBridge every 5 minutes, implemented with the `provided.al2023` custom runtime.
- **DynamoDB** — PAY_PER_REQUEST demo table.
- **API Gateway REST API** — 10 CRUD endpoints, API key, usage plan, validation, CORS, stage throttling and access logs.

## Prerequisites

AWS CLI configured with permission to create IAM, Lambda, API Gateway, DynamoDB, S3, SQS, EventBridge and CloudWatch resources; Terraform >= 1.5; Go is **not required on the deployment host** because the custom runtime bootstrap binary is included. The custom runtime binary is built for x86_64.

## Deploy

```bash
terraform init
terraform fmt -recursive
terraform validate
terraform plan
terraform apply
```

Terraform uses the `archive` provider to package Lambda source automatically into `build/`; there are no prebuilt Lambda ZIPs or deployment scripts to maintain.

Default region is `ap-south-1`. Lambda Insights is enabled by default using the current documented Mumbai extension ARN. If you change region, set `lambda_insights_layer_arn` to the Insights extension ARN for that region.

## API key

```bash
API_URL=$(terraform output -raw api_url)
API_KEY_ID=$(terraform output -raw api_key_id)
API_KEY=$(aws apigateway get-api-key --api-key "$API_KEY_ID" --include-value --query value --output text)
curl -i -H "x-api-key: $API_KEY" "$API_URL/users?limit=10"
```

## Test every assignment item

### 1. API endpoints and status codes

```bash
curl -sS -H "x-api-key: $API_KEY" "$API_URL/users?limit=10"
curl -sS -X POST -H "x-api-key: $API_KEY" -H 'Content-Type: application/json' -d '{"name":"Manoj","email":"manoj@example.com"}' "$API_URL/users"
curl -sS -H "x-api-key: $API_KEY" "$API_URL/users/123"
curl -sS -X PUT -H "x-api-key: $API_KEY" -H 'Content-Type: application/json' -d '{"name":"Updated","email":"u@example.com"}' "$API_URL/users/123"
curl -sS -X DELETE -H "x-api-key: $API_KEY" "$API_URL/users/123"
curl -sS -H "x-api-key: $API_KEY" "$API_URL/products"
curl -sS -X POST -H "x-api-key: $API_KEY" -H 'Content-Type: application/json' -d '{"name":"Laptop","price":50000}' "$API_URL/products"
curl -sS -H "x-api-key: $API_KEY" "$API_URL/products/123"
curl -sS -X PUT -H "x-api-key: $API_KEY" -H 'Content-Type: application/json' -d '{"name":"Laptop Pro","price":60000}' "$API_URL/products/123"
curl -sS -X DELETE -H "x-api-key: $API_KEY" "$API_URL/products/123"
```

### 2. API key authentication

Without `x-api-key`, a protected endpoint should return **403**. With the key, it should reach Lambda.

### 3. Request validation

Invalid user body should be rejected by API Gateway with **400**:
```bash
curl -i -X POST -H "x-api-key: $API_KEY" -H 'Content-Type: application/json' -d '{"name":"A"}' "$API_URL/users"
```
The `limit` query parameter is required on `GET /users`.

### 4. Controlled 500 test

The API Lambda supports a test-only query flag:
```bash
curl -i -H "x-api-key: $API_KEY" "$API_URL/users?limit=10&force_error=true"
```
It returns the standard **500** response while logs contain `request_failed`.

### 5. Correlation ID and structured logging

```bash
curl -i -H "x-api-key: $API_KEY" -H "X-Correlation-ID: TEST-12345" "$API_URL/users?limit=10"
aws logs tail "/aws/lambda/$(terraform output -raw api_lambda_name)" --since 10m
```
Every application log is JSON and includes correlation/request context.

### 6. Cold start and provisioned concurrency

For an on-demand cold-start demonstration, invoke a newly published version directly and inspect Lambda REPORT logs. Search Logs Insights with:

```text
fields @timestamp, @requestId, @duration, @billedDuration, @maxMemoryUsed, @memorySize, @initDuration
| filter @type = "REPORT"
| sort @timestamp desc
| limit 50
```

`Init Duration` indicates initialization work for a cold-started environment. The `live` alias has provisioned concurrency enabled by default. Check:

```bash
aws lambda get-provisioned-concurrency-config --function-name "$(terraform output -raw api_lambda_name)" --qualifier live
aws cloudwatch get-metric-statistics --namespace AWS/Lambda --metric-name ProvisionedConcurrencyInvocations --dimensions Name=FunctionName,Value="$(terraform output -raw api_lambda_name)" Name=Resource,Value="$(terraform output -raw api_lambda_name):live" --statistics Sum --period 60 --start-time "$(date -u -d '10 minutes ago' +%FT%TZ)" --end-time "$(date -u +%FT%TZ)"
```

### 7. Reserved concurrency and Lambda throttling

```bash
aws lambda get-function-concurrency --function-name "$(terraform output -raw api_lambda_name)"
```
It should show 10. To create overlap and test the limit without API Gateway throttling, invoke Lambda directly in parallel with a test event containing `sleep=2`. For example, save an event with `queryStringParameters: {"sleep":"2"}` and start 50 concurrent `aws lambda invoke` commands. Check `AWS/Lambda` metrics `ConcurrentExecutions` and `Throttles`.

### 8. API Gateway throttling

Stage throttle is 10 requests/sec with burst 20. A load test can be run with ApacheBench:
```bash
sudo apt-get update && sudo apt-get install -y apache2-utils
ab -n 200 -c 30 -H "x-api-key: $API_KEY" "$API_URL/users?limit=10"
```
Some requests may receive **429** when the configured gateway/usage-plan limits are exceeded.

### 9. Usage plan (~100 requests/minute)

The REST API usage plan uses a 1.6667 requests/sec rate with burst 5, which is approximately 100 requests/minute average. API Gateway REST usage plans do not provide a literal per-minute rate setting; rate/burst throttling is the applicable mechanism.

### 10. S3 trigger

```bash
echo hello > test.txt
aws s3 cp test.txt "s3://$(terraform output -raw s3_bucket)/"
aws logs tail "/aws/lambda/serverless-demo-dev-s3" --since 5m
```
Use the Lambda name `serverless-demo-dev-s3` if the last command cannot derive it.

### 11. SQS trigger

```bash
aws sqs send-message --queue-url "$(terraform output -raw sqs_queue_url)" --message-body '{"hello":"world"}'
aws logs tail "/aws/lambda/serverless-demo-dev-sqs" --since 5m
```

### 12. EventBridge schedule/custom runtime

Wait for the five-minute rule, then:
```bash
aws logs tail "/aws/lambda/serverless-demo-dev-scheduled" --since 10m
```
The scheduled function uses `provided.al2023` and the included `bootstrap` runtime binary.

### 13. Lambda Layer and memory metric

```bash
aws lambda get-function --function-name "$(terraform output -raw api_lambda_name)" --query 'Configuration.Layers[*].Arn'
```
CloudWatch Logs Insights for the application memory metric:
```text
fields @timestamp, @message
| filter event = "request_completed"
| sort @timestamp desc
| limit 50
```
The `ServerlessApp/MemoryUsedMB` metric is created from structured logs. AWS Lambda REPORT logs also expose `Max Memory Used` for the authoritative Lambda runtime measurement.

### 14. Lambda Insights

Open CloudWatch > Lambda > Insights or inspect the Lambda Insights metrics. The extension provides CPU, memory, network/disk and initialization-related telemetry.

### 15. OpenAPI and client SDK

The API contract is in `docs/openapi.yaml`. Validate it with any OpenAPI 3 validator, then generate SDKs with OpenAPI Generator, for example:
```bash
npx @openapitools/openapi-generator-cli generate -i docs/openapi.yaml -g javascript -o generated-sdk/javascript
npx @openapitools/openapi-generator-cli generate -i docs/openapi.yaml -g python -o generated-sdk/python
```

## Cleanup

```bash
terraform destroy
```

## Requirement map

| Requirement | Implementation / proof |
|---|---|
| 4 Lambda functions | API, S3, SQS, EventBridge scheduled |
| S3/SQS/EventBridge triggers | Terraform integrations |
| Provisioned concurrency | `api_live` alias + provisioned concurrency config |
| Lambda Insights | Managed Insights layer + execution policy |
| Custom runtime | Scheduled Lambda `provided.al2023` + Go bootstrap |
| Lambda Layer | `layer/` packaged by `archive_file` |
| Reserved concurrency | API Lambda set to 10 |
| JSON logs/correlation IDs | API and common logger |
| Duration/memory metrics | CloudWatch metric filters |
| Concurrent/throttle tests | Direct Lambda load + API Gateway load test |
| Environment variables | Lambda configuration |
| 8+ REST endpoints | 10 CRUD endpoints |
| Request validation | API Gateway validator/models |
| 200/201/400/404/500 | Lambda/gateway response paths |
| API key/usage plan | API key + usage plan |
| CORS | OPTIONS mock + Lambda headers |
| 10 req/sec throttle | API stage settings |
| CloudWatch API logs | API Gateway access logs |
| OpenAPI/Swagger | `docs/openapi.yaml` |
| Client SDKs | OpenAPI Generator commands |
