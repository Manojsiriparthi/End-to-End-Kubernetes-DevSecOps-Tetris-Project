import json
import logging


logger = logging.getLogger()


def log_event(event_name, **kwargs):
    logger.info(
        json.dumps(
            {
                "event": event_name,
                **kwargs,
            },
            default=str,
        )
    )
